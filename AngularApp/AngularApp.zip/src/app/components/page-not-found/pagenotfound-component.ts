import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-error',
  template: '<h2> Page Not Found </h2>'
 
})
export class PageNotFoundComponent  {


}
